import React from 'react';

interface BadgeProps {
  status: 'CONNECTED' | 'DISCONNECTED';
}

export const Badge: React.FC<BadgeProps> = ({ status }) => {
  const isConnected = status === 'CONNECTED';
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
        isConnected
          ? 'bg-success/10 text-success border-success/20'
          : 'bg-destructive/10 text-destructive border-destructive/20'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${isConnected ? 'bg-success' : 'bg-destructive'}`}></span>
      {isConnected ? 'Conectado' : 'Desconectado'}
    </span>
  );
};