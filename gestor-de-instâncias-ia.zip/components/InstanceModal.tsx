import React, { useState, useEffect } from 'react';
import { Agent, Instance } from '../types';
import { X, Save, AlertTriangle, ShieldCheck, Folder, Info, Calendar } from 'lucide-react';
import { Badge } from './ui/Badge';

interface InstanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  instance: Instance;
  allReservaAgents: Agent[];
  allInstances: Instance[];
  allAgents: Agent[];
  onSave: (updatedInstance: Instance) => void;
  onSwapReserva: (instanceId: string, newReservaId: string) => { success: boolean; message: string; swappedWithInstanceName?: string };
}

export const InstanceModal: React.FC<InstanceModalProps> = ({
  isOpen,
  onClose,
  instance,
  allReservaAgents,
  onSave,
  onSwapReserva,
  allInstances,
  allAgents
}) => {
  const [formData, setFormData] = useState<Instance>(instance);
  const [selectedReservaId, setSelectedReservaId] = useState<string>(instance.reservaAgentId);
  const [swapMessage, setSwapMessage] = useState<{ text: string; type: 'info' | 'warning' } | null>(null);

  // Sync state
  useEffect(() => {
    setFormData(instance);
    setSelectedReservaId(instance.reservaAgentId);
    setSwapMessage(null);
  }, [instance]);

  // Swap logic check
  useEffect(() => {
    if (selectedReservaId === instance.reservaAgentId) {
      setSwapMessage(null);
      return;
    }
    const otherInstance = allInstances.find(
      (inst) => inst.reservaAgentId === selectedReservaId && inst.id !== instance.id
    );
    if (otherInstance) {
      setSwapMessage({
        type: 'warning',
        text: `O sistema fará a troca automática com "${otherInstance.name}".`
      });
    } else {
      setSwapMessage(null);
    }
  }, [selectedReservaId, allInstances, instance]);

  if (!isOpen) return null;

  // Helpers
  const titularAgent = allAgents.find(a => a.id === formData.titularAgentId);
  const displayName = titularAgent ? titularAgent.name : formData.name;
  
  const initials = displayName
    .split(' ')
    .filter(word => word.length > 2)
    .slice(0, 2)
    .map(w => w[0])
    .join('')
    .toUpperCase();

  const handleSave = () => {
    if (selectedReservaId !== instance.reservaAgentId) {
      onSwapReserva(instance.id, selectedReservaId);
    }
    onSave({ ...formData, reservaAgentId: selectedReservaId });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-card w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* --- Header --- */}
        <div className="px-8 py-6 border-b border-border flex items-start justify-between bg-white dark:bg-card">
          <div className="flex items-center gap-4">
            {/* Avatar */}
            <div className="w-14 h-14 rounded-xl bg-secondary text-secondary-foreground flex items-center justify-center text-xl font-bold border border-border shadow-sm">
              {initials}
            </div>
            
            {/* Titles */}
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-2xl font-bold text-foreground tracking-tight">{displayName}</h2>
                <Badge status={formData.status} />
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm font-medium">
                <Folder size={14} className="text-muted-foreground/70" />
                {formData.segment}
              </div>
            </div>
          </div>

          <button 
            onClick={onClose} 
            className="text-muted-foreground hover:text-foreground hover:bg-muted p-2 rounded-full transition-all"
          >
            <X size={24} />
          </button>
        </div>

        {/* --- Content --- */}
        <div className="p-8 overflow-y-auto flex-1 bg-white dark:bg-card">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
            
            {/* LEFT COLUMN (Reserva + Periodo) */}
            <div className="lg:col-span-5 flex flex-col gap-8">
              
              {/* Card Reserva (Azul) */}
              <div className="bg-blue-50/50 dark:bg-blue-950/10 border border-blue-100 dark:border-blue-900 rounded-xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2 text-blue-700 dark:text-blue-400 text-xs font-bold uppercase tracking-wider">
                    <ShieldCheck size={16} />
                    Agente Reserva
                  </div>
                  <span className="text-blue-600 cursor-pointer text-xs font-medium hover:underline">
                    Trocar Agente
                  </span>
                </div>

                <div className="relative mb-3">
                  <select
                    value={selectedReservaId}
                    onChange={(e) => setSelectedReservaId(e.target.value)}
                    className="w-full text-base font-medium px-4 py-3 rounded-lg border border-blue-200 dark:border-blue-800 bg-white dark:bg-card text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none appearance-none shadow-sm transition-all cursor-pointer"
                  >
                    {allReservaAgents.map((agent) => (
                      <option key={agent.id} value={agent.id}>
                        {agent.name}
                      </option>
                    ))}
                  </select>
                  {/* Custom Arrow if needed, but native is fine for MVP */}
                </div>

                {swapMessage ? (
                  <div className="text-xs text-orange-600 bg-orange-50 p-2 rounded border border-orange-100 flex gap-2 items-start">
                    <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                    {swapMessage.text}
                  </div>
                ) : (
                  <div className="flex gap-2 text-xs text-blue-600/80 leading-relaxed">
                    <Info size={14} className="shrink-0 mt-0.5" />
                    Lista restrita apenas a <span className="font-bold">Agentes de Reserva</span>. Ao selecionar um agente ocupado, o sistema fará a <span className="font-bold">troca automática</span>.
                  </div>
                )}
              </div>

              {/* Período */}
              <div>
                <label className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">
                  Período de Atuação
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="block text-[10px] text-muted-foreground font-semibold mb-1.5 uppercase">Data Início</span>
                    <div className="relative">
                      <input
                        type="date"
                        value={formData.periodStart}
                        onChange={(e) => setFormData({ ...formData, periodStart: e.target.value })}
                        className="w-full pl-3 pr-8 py-2.5 rounded-lg border border-border bg-white dark:bg-card text-sm text-foreground focus:ring-2 focus:ring-primary outline-none font-medium"
                      />
                      <Calendar size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                    </div>
                  </div>
                  <div>
                    <span className="block text-[10px] text-muted-foreground font-semibold mb-1.5 uppercase">Data Fim</span>
                    <div className="relative">
                      <input
                        type="date"
                        value={formData.periodEnd}
                        onChange={(e) => setFormData({ ...formData, periodEnd: e.target.value })}
                        className="w-full pl-3 pr-8 py-2.5 rounded-lg border border-border bg-white dark:bg-card text-sm text-foreground focus:ring-2 focus:ring-primary outline-none font-medium"
                      />
                       <Calendar size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN */}
            <div className="lg:col-span-7 flex flex-col gap-8">
              
              {/* Métricas Cards */}
              <div className="grid grid-cols-2 gap-4">
                <div className="border border-border rounded-xl p-4 bg-white dark:bg-card shadow-sm">
                  <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Disparos Hoje</div>
                  <input 
                    type="number"
                    value={formData.dailyShots}
                    onChange={(e) => setFormData({ ...formData, dailyShots: parseInt(e.target.value) || 0 })}
                    className="text-3xl font-bold text-foreground bg-transparent w-full outline-none focus:underline decoration-dashed decoration-border"
                  />
                </div>
                <div className="border border-border rounded-xl p-4 bg-white dark:bg-card shadow-sm">
                  <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Limite Diário</div>
                  <div className="flex items-baseline gap-1">
                    <input 
                      type="number"
                      value={formData.limitShots}
                      onChange={(e) => setFormData({ ...formData, limitShots: parseInt(e.target.value) || 0 })}
                      className="text-3xl font-bold text-foreground bg-transparent max-w-[120px] outline-none focus:underline decoration-dashed decoration-border"
                    />
                    <span className="text-sm font-medium text-muted-foreground">msgs</span>
                  </div>
                </div>
              </div>

              {/* Segmento Read-only Look */}
              <div>
                <label className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                  Segmento Atual
                </label>
                <div className="flex items-center gap-3 px-4 py-3 rounded-lg border border-border bg-white dark:bg-card shadow-sm text-foreground">
                  <Folder size={18} className="text-muted-foreground" />
                  <span className="font-medium">{formData.segment}</span>
                </div>
              </div>

              {/* Diretriz */}
              <div className="flex-1 flex flex-col">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                    <div className="w-2 h-0.5 bg-muted-foreground/50 rounded-full"></div>
                    Diretriz
                  </label>
                  <span className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 text-[10px] font-bold px-2 py-0.5 rounded border border-yellow-200 dark:border-yellow-800/50 uppercase">
                    Editável
                  </span>
                </div>
                <textarea
                  value={formData.diretriz}
                  onChange={(e) => setFormData({ ...formData, diretriz: e.target.value })}
                  className="w-full flex-1 min-h-[140px] px-4 py-3 rounded-xl border border-border bg-white dark:bg-card text-foreground focus:ring-2 focus:ring-primary focus:border-primary outline-none resize-none shadow-sm text-sm leading-relaxed"
                  placeholder="Escreva as diretrizes..."
                />
              </div>

            </div>

          </div>
        </div>

        {/* --- Footer --- */}
        <div className="px-8 py-5 border-t border-border bg-white dark:bg-card flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-sm font-bold text-muted-foreground border border-border rounded-lg hover:bg-muted hover:text-foreground transition-all"
          >
            Cancelar
          </button>
          <button 
            onClick={handleSave}
            className="px-6 py-2.5 bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-bold rounded-lg shadow-sm flex items-center gap-2 transition-all transform active:scale-95"
          >
            <Save size={18} />
            Salvar Alterações
          </button>
        </div>

      </div>
    </div>
  );
};