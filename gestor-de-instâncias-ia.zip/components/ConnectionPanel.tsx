import React from 'react';
import { Instance, Agent } from '../types';
import { Badge } from './ui/Badge';
import { ChevronRight } from 'lucide-react';
import { DashboardMetrics } from './DashboardMetrics';

interface ConnectionPanelProps {
  instances: Instance[];
  agents: Agent[];
  onOpenInstance: (instance: Instance) => void;
}

interface InstanceRowProps {
  instance: Instance;
  agents: Agent[];
  onClick: (instance: Instance) => void;
}

const InstanceRow: React.FC<InstanceRowProps> = ({ instance, agents, onClick }) => {
  // Find titular agent name
  const titularAgent = agents.find(a => a.id === instance.titularAgentId);
  const displayName = titularAgent ? titularAgent.name : instance.name;

  // Generate initials from Agent name
  const initials = displayName
    .split(' ')
    .filter(word => word.length > 2 || /^\d+$/.test(word)) 
    .slice(0, 2)
    .map(w => w[0])
    .join('')
    .toUpperCase();

  return (
    <div 
      onClick={() => onClick(instance)}
      className="group flex items-center justify-between p-4 bg-white dark:bg-card border border-border rounded-lg shadow-sm hover:shadow-md hover:border-primary/50 transition-all cursor-pointer"
    >
      <div className="flex items-center gap-4 overflow-hidden">
        {/* Avatar Circle */}
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center font-bold text-sm border border-border">
          {initials}
        </div>
        
        {/* Agent Name (Titular) and Segment */}
        <div className="flex flex-col min-w-0">
          <h3 className="font-semibold text-foreground text-base truncate group-hover:text-primary transition-colors">
            {displayName}
          </h3>
          <p className="text-[10px] md:text-xs text-muted-foreground uppercase tracking-wider font-semibold truncate">
            {instance.segment}
          </p>
        </div>
      </div>

      {/* Status Badge & Chevron */}
      <div className="flex items-center gap-2 md:gap-4 flex-shrink-0 ml-4">
        <div className="scale-90 md:scale-100">
           <Badge status={instance.status} />
        </div>
        <ChevronRight size={16} className="text-muted-foreground/40 group-hover:text-primary transition-colors" />
      </div>
    </div>
  );
};

export const ConnectionPanel: React.FC<ConnectionPanelProps> = ({ instances, agents, onOpenInstance }) => {
  const connected = instances.filter((i) => i.status === 'CONNECTED');
  const disconnected = instances.filter((i) => i.status === 'DISCONNECTED');

  return (
    <div>
      {/* Dashboard Metrics Cards */}
      <DashboardMetrics instances={instances} />

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 md:gap-8">
        
        {/* Coluna Conectados */}
        <div className="bg-white/50 dark:bg-card/50 rounded-xl p-0 md:p-4">
          <div className="flex items-center gap-2 mb-4 px-1">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse"></div>
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              Conectadas 
              <span className="bg-success/10 text-success text-xs px-2 py-0.5 rounded-full font-bold border border-success/20">
                {connected.length}
              </span>
            </h2>
          </div>
          
          <div className="space-y-3">
            {connected.map((instance) => (
              <InstanceRow 
                key={instance.id} 
                instance={instance}
                agents={agents}
                onClick={onOpenInstance}
              />
            ))}
            {connected.length === 0 && (
              <div className="p-8 text-center border border-dashed border-border rounded-lg bg-muted/10">
                 <p className="text-muted-foreground text-sm">Nenhuma instância conectada.</p>
              </div>
            )}
          </div>
        </div>

        {/* Coluna Desconectados */}
        <div className="bg-white/50 dark:bg-card/50 rounded-xl p-0 md:p-4">
          <div className="flex items-center gap-2 mb-4 px-1">
            <div className="w-2 h-2 rounded-full bg-destructive animate-pulse"></div>
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              Desconectadas 
              <span className="bg-destructive/10 text-destructive text-xs px-2 py-0.5 rounded-full font-bold border border-destructive/20">
                {disconnected.length}
              </span>
            </h2>
          </div>
          
          <div className="space-y-3">
            {disconnected.map((instance) => (
              <InstanceRow 
                key={instance.id} 
                instance={instance}
                agents={agents} 
                onClick={onOpenInstance}
              />
            ))}
             {disconnected.length === 0 && (
              <div className="p-8 text-center border border-dashed border-border rounded-lg bg-muted/10">
                 <p className="text-muted-foreground text-sm">Nenhuma instância desconectada.</p>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};