import React from 'react';
import { Instance, Agent } from '../types';
import { Folder } from 'lucide-react';

interface SpreadsheetViewProps {
  instances: Instance[];
  allAgents: Agent[];
  onOpenInstance: (instance: Instance) => void;
}

export const SpreadsheetView: React.FC<SpreadsheetViewProps> = ({ instances, allAgents, onOpenInstance }) => {
  // Get unique segments
  const segments = Array.from(new Set(instances.map((i) => i.segment)));

  // Helper to get agent name
  const getAgentName = (id: string) => allAgents.find((a) => a.id === id)?.name || id;

  // Helper to format numbers
  const formatNumber = (num: number) => new Intl.NumberFormat('pt-BR').format(num);

  return (
    <div className="space-y-8 pb-10">
      {segments.map((segment) => {
        const segmentInstances = instances.filter((i) => i.segment === segment);
        
        return (
          <div key={segment} className="bg-white dark:bg-card border border-border rounded-xl shadow-sm overflow-hidden">
            {/* Header do Segmento (Card Header) */}
            <div className="px-6 py-4 border-b border-border flex justify-between items-center bg-slate-50/50 dark:bg-muted/10">
              <div className="flex items-center gap-3">
                <Folder className="text-blue-600" size={20} />
                <h3 className="font-bold text-foreground text-base tracking-tight">{segment}</h3>
              </div>
              <span className="text-xs font-semibold text-muted-foreground border border-border px-3 py-1.5 rounded-md bg-white dark:bg-card shadow-sm">
                {segmentInstances.length} Instâncias
              </span>
            </div>

            {/* Tabela Interna */}
            <div className="w-full overflow-x-auto">
              <div className="min-w-[700px]">
                {/* Cabeçalho da Tabela */}
                <div className="grid grid-cols-12 px-6 py-3 border-b border-border bg-white dark:bg-card">
                  <div className="col-span-1 flex justify-center text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                    Status
                  </div>
                  <div className="col-span-4 text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                    Titular
                  </div>
                  <div className="col-span-4 text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                    Reserva
                  </div>
                  <div className="col-span-3 text-right text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                    Disparos/Limite
                  </div>
                </div>

                {/* Linhas da Tabela */}
                <div className="divide-y divide-border">
                  {segmentInstances.map((instance) => (
                    <div 
                      key={instance.id}
                      onClick={() => onOpenInstance(instance)}
                      className="grid grid-cols-12 px-6 py-4 items-center hover:bg-muted/30 cursor-pointer transition-colors group"
                    >
                      {/* Coluna Status (Círculo) */}
                      <div className="col-span-1 flex justify-center">
                        <div 
                          className={`w-3 h-3 rounded-full border-2 ${
                            instance.status === 'CONNECTED' 
                              ? 'border-success' 
                              : 'border-destructive'
                          }`} 
                          title={instance.status === 'CONNECTED' ? 'Conectado' : 'Desconectado'}
                        />
                      </div>

                      {/* Coluna Titular */}
                      <div className="col-span-4 font-semibold text-foreground text-sm group-hover:text-primary transition-colors">
                        {getAgentName(instance.titularAgentId)}
                      </div>

                      {/* Coluna Reserva */}
                      <div className="col-span-4 text-muted-foreground text-sm">
                        {getAgentName(instance.reservaAgentId)}
                      </div>

                      {/* Coluna Disparos/Limite */}
                      <div className="col-span-3 text-right text-sm tabular-nums">
                        <span className="font-bold text-foreground">{formatNumber(instance.dailyShots)}</span>
                        <span className="text-muted-foreground/40 mx-1.5 font-light">/</span>
                        <span className="text-muted-foreground font-normal">{formatNumber(instance.limitShots)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};