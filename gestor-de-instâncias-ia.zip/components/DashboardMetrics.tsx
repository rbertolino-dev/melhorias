import React from 'react';
import { Instance } from '../types';
import { Wifi, TrendingUp } from 'lucide-react';

interface DashboardMetricsProps {
  instances: Instance[];
}

export const DashboardMetrics: React.FC<DashboardMetricsProps> = ({ instances }) => {
  // Calculations
  const totalInstances = instances.length;
  const onlineInstances = instances.filter(i => i.status === 'CONNECTED').length;
  
  const totalDailyShots = instances.reduce((acc, curr) => acc + curr.dailyShots, 0);
  const totalLimitShots = instances.reduce((acc, curr) => acc + curr.limitShots, 0);

  // Formatters
  const formatNumber = (num: number) => new Intl.NumberFormat('pt-BR').format(num);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      
      {/* Card 1: Instâncias Totais */}
      <div className="bg-white dark:bg-card border border-border rounded-xl p-5 shadow-sm flex flex-col justify-between h-[110px]">
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            Instâncias Totais
          </span>
        </div>
        <div className="flex items-end justify-between">
          <span className="text-3xl font-bold text-foreground">{totalInstances}</span>
          <span className="bg-blue-100 text-blue-700 text-[10px] font-bold px-1.5 py-0.5 rounded border border-blue-200">
            100%
          </span>
        </div>
      </div>

      {/* Card 2: Online Agora */}
      <div className="bg-white dark:bg-card border border-border rounded-xl p-5 shadow-sm flex flex-col justify-between h-[110px]">
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            Online Agora
          </span>
        </div>
        <div className="flex items-end justify-between">
          <span className="text-3xl font-bold text-success">{onlineInstances}</span>
          <div className="bg-success/10 p-1.5 rounded-full text-success">
            <Wifi size={20} />
          </div>
        </div>
      </div>

      {/* Card 3: Disparos Hoje */}
      <div className="bg-white dark:bg-card border border-border rounded-xl p-5 shadow-sm flex flex-col justify-between h-[110px]">
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            Disparos Hoje
          </span>
        </div>
        <div className="flex items-end justify-between">
          <span className="text-3xl font-bold text-foreground">{formatNumber(totalDailyShots)}</span>
          <div className="flex items-center gap-1 text-[10px] font-bold text-success bg-success/5 px-1.5 py-0.5 rounded border border-success/10">
            <TrendingUp size={12} />
            +5%
          </div>
        </div>
      </div>

      {/* Card 4: Limite Total Diário */}
      <div className="bg-white dark:bg-card border border-border rounded-xl p-5 shadow-sm flex flex-col justify-between h-[110px]">
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            Limite Total Diário
          </span>
        </div>
        <div className="flex items-end justify-between">
          <span className="text-3xl font-bold text-foreground">{formatNumber(totalLimitShots)}</span>
          <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">
            Capacidade
          </span>
        </div>
      </div>

    </div>
  );
};